package equipoluca;

public interface Mascota {
    
       public abstract void jugar();

}
