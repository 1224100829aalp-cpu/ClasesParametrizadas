package equipoluca;

public class Capibara extends Animal {

    public Capibara(String nombre, int edad) {
        super(nombre, edad);
    }

    public void hacerSonido() {
        System.out.println(nombre + " la capibara chilla");
    }

    public void moverse() {
        System.out.println(nombre + " la capibara camina");
    }
    
    public void jugar(){
    }

}