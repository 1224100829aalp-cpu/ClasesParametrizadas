package equipoluca;

public class MainZoo {

    public static void main(String[] args) {
        Animal[] zoo = new Animal[3];
        zoo[0]= new Pajaro("Piolin",2);
        zoo[1]= new Jaguar("Toño",3);
        zoo[2]= new Capibara("Panchito",4);

        System.out.println("Bienvenido al zoo Luca");
        for (Animal animal : zoo) {
            System.out.println(animal.getNombre() + " tiene " + animal.getEdad() + " años.");

            animal.hacerSonido();
            animal.moverse();

            if (animal instanceof Mascota mascota) {
                mascota.jugar();
            }

            System.out.println(); 
        }
    }
}
   

