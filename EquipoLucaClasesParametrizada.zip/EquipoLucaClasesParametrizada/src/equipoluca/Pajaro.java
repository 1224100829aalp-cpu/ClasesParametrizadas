package equipoluca;

public class Pajaro extends Animal {

    public Pajaro(String nombre, int edad) {
        super(nombre, edad);
    }

    public void hacerSonido() {
        System.out.println(nombre + " el pajaro dice: Pio pio");
    }

    public void moverse() {
        System.out.println(nombre + " esta volando alto.");
    }
}