package equipoluca;

public class Jaguar extends Animal {

    public Jaguar(String nombre, int edad) {
        super(nombre, edad);
    }

    public void hacerSonido() {
        System.out.println(nombre + " el jaguar ruje");
    }

    public void moverse() {
        System.out.println(nombre + " esta corriendo rapido");
    }
}